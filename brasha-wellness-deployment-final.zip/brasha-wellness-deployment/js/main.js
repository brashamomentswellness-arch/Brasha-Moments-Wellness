// Navbar scroll effect
window.addEventListener('scroll', function() {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const offsetTop = target.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Form submission handler
document.getElementById('appointmentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(this);
    
    // Show success message
    alert('Thank you for your interest in Brasha Moments Wellness!\n\nWe have received your appointment request and will contact you within 24 hours to confirm your appointment.\n\nFor immediate assistance, please call +254 763 400 917.\n\nYour information is kept strictly confidential.');
    
    // Reset form
    this.reset();
    
    // In a real implementation, you would send this data to a server
    // Example: 
    // fetch('/api/appointments', {
    //     method: 'POST',
    //     body: formData
    // })
});

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe service cards and pricing cards
document.querySelectorAll('.service-card, .pricing-card, .gallery-item').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(card);
});

// Mobile menu toggle (if needed in future)
const createMobileMenu = () => {
    const navContainer = document.querySelector('.nav-container');
    const navLinks = document.querySelector('.nav-links');
    
    // This is a placeholder for mobile menu functionality
    // Can be expanded when needed
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Brasha Moments Wellness website loaded successfully');
    
    // Add any initialization code here
    // Example: Analytics tracking, third-party integrations, etc.
});

// Gallery lightbox effect (simple version)
document.querySelectorAll('.gallery-item').forEach(item => {
    item.addEventListener('click', function() {
        // Simple alert for now - can be replaced with a proper lightbox
        const imgSrc = this.querySelector('img').src;
        const title = this.querySelector('h3').textContent;
        
        // In a full implementation, this would open a modal/lightbox
        console.log('Gallery item clicked:', title);
    });
});
